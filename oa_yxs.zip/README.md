1、组长版

	1.1、注册github、绿色按钮new responsity

	1.2、github工具，项目目录中右键选择git bash here

	1.3、

	git init  //初始化项目的本地仓库

	git add ./    //项目所有的文件/目录都要提交

	git commit -m "项目第一次初始化"

	git remote add origin https://github.com/minghuaPu/oa_yxs.git   //修改本地仓库的.config配置文件
	
	git push -u origin master   //推送到远程仓库


2、组员版

	2.1、注册github

	2.2、我们的项目仓库地址是https://github.com/minghuaPu/oa_yxs.git，克隆（clone）到电脑

	2.3、改动了代码后，git add ./   //懒办法，推荐（找到文件相对目录）
	
	2.4、git commit -m '优化时间输入框'

	2.5、git push -u origin master   //推送到远程仓库


3、大众版

	下班前提交（push）

	上班后更新（pull）

