<?php
namespace app\index\controller;

class Business extends \think\Controller
{
    public function index()
    {
        return $this->fetch();
    } 
}
