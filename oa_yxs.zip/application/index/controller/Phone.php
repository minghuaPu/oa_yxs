<?php
namespace app\index\controller;

class Phone extends \think\Controller
{
    public function index()
    {
        return $this->fetch();
    }
    
}
